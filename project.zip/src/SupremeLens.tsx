import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence, useAnimation } from 'framer-motion';
import gsap from 'gsap';
import { Camera, X, ScanFocus } from 'lucide-react';
import { GoogleGenerativeAI } from '@google/generative-ai';

// Initialize Gemini (Ensure VITE_GEMINI_API_KEY is in your .env)
const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);

interface SupremeLensProps {
  onClose: () => void;
}

export default function SupremeLens({ onClose }: SupremeLensProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [resultText, setResultText] = useState('');
  const [displayedText, setDisplayedText] = useState('');
  const [drawerState, setDrawerState] = useState<'hidden' | 'peek' | 'full'>('hidden');

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageContainerRef = useRef<HTMLDivElement>(null);
  const scanlineRef = useRef<HTMLDivElement>(null);
  const drawerControls = useAnimation();

  // START CAMERA
  useEffect(() => {
    async function startCamera() {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' }
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (err) {
        console.error("Camera access denied", err);
        alert("Need camera access for Supreme Lens!");
      }
    }
    startCamera();
    return () => stopCamera();
  }, []);

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
  };

  // CAPTURE & PROCESS
  const handleSnap = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    // 1. Capture Image
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    const base64Image = canvas.toDataURL('image/jpeg');
    setCapturedImage(base64Image);
    setIsProcessing(true);
    stopCamera();

    // 2. GSAP Scanline Animation
    if (scanlineRef.current && imageContainerRef.current) {
      gsap.to(scanlineRef.current, {
        y: imageContainerRef.current.clientHeight,
        duration: 1.5,
        repeat: -1,
        yoyo: true,
        ease: "linear"
      });
    }

    // 3. Call Gemini API
    try {
      const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
      const prompt = "You are a gourmet Tagalog translator and cultural concierge. Analyze this image. If it's a menu or sign, extract the text and translate it into English, providing an elegant, concise description of the items, ingredients, and cultural vibe. If it's an object, describe it beautifully in Tagalog and English. Use a sophisticated, confident, and premium tone. No fluff.";
      
      const imagePart = {
        inlineData: {
          data: base64Image.split(',')[1],
          mimeType: "image/jpeg"
        }
      };

      const result = await model.generateContent([prompt, imagePart]);
      const text = result.response.text();
      
      setResultText(text);
      setIsProcessing(false);
      gsap.killTweensOf(scanlineRef.current); // Stop scanline
      
      // Trigger Drawer
      setDrawerState('peek');
      drawerControls.start({ y: "50%" }); 
    } catch (error) {
      console.error(error);
      setResultText("Error communicating with the oracle. Try again.");
      setIsProcessing(false);
      setDrawerState('peek');
      drawerControls.start({ y: "50%" });
    }
  };

  // TYPEWRITER EFFECT
  useEffect(() => {
    if (resultText && drawerState !== 'hidden') {
      let i = 0;
      const interval = setInterval(() => {
        setDisplayedText(resultText.slice(0, i));
        i += 2; // Fast typing speed
        if (i > resultText.length) clearInterval(interval);
      }, 10);
      return () => clearInterval(interval);
    }
  }, [resultText, drawerState]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className="fixed inset-0 z-50 bg-[#cdddb7] p-4 flex flex-col font-['Noto_Sans_Tagalog']"
    >
      {/* Header */}
      <div className="flex justify-between items-center mb-4 mt-8">
        <h2 className="text-2xl font-black tracking-tighter uppercase text-[#1A1A1A]" style={{ WebkitTextStroke: '1px white' }}>
          Supreme Lens
        </h2>
        <button onClick={() => { stopCamera(); onClose(); }} className="p-2 bg-[#E8E6E1] border-4 border-[#1A1A1A] rounded-xl shadow-[4px_4px_0px_#1A1A1A] active:translate-y-1 active:shadow-[0px_0px_0px_#1A1A1A] transition-all">
          <X strokeWidth={3} />
        </button>
      </div>

      {/* Viewfinder Container */}
      <div ref={imageContainerRef} className="relative flex-grow rounded-2xl border-[6px] border-[#1A1A1A] overflow-hidden bg-black shadow-[8px_8px_0px_#1A1A1A]">
        {!capturedImage ? (
          <video ref={videoRef} autoPlay playsInline className="absolute inset-0 w-full h-full object-cover" />
        ) : (
          <>
            <img src={capturedImage} alt="Captured" className="absolute inset-0 w-full h-full object-cover" />
            {isProcessing && (
              <>
                <div className="absolute inset-0 bg-black/40 z-10" />
                <div ref={scanlineRef} className="absolute top-0 left-0 w-full h-2 bg-[#FDE047] shadow-[0_0_15px_#FDE047] z-20" />
                <div className="absolute inset-0 z-30 flex items-center justify-center">
                  <span className="text-white font-bold text-xl tracking-widest uppercase animate-pulse">Scanning...</span>
                </div>
              </>
            )}
          </>
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>

      {/* Capture Button */}
      {!capturedImage && (
        <div className="mt-8 mb-10 flex justify-center">
          <button 
            onClick={handleSnap}
            className="w-20 h-20 bg-[#FDE047] rounded-full border-4 border-[#1A1A1A] shadow-[6px_6px_0px_#1A1A1A] active:translate-y-2 active:shadow-[0px_0px_0px_#1A1A1A] transition-all flex items-center justify-center"
          >
            <ScanFocus size={32} strokeWidth={2.5} color="#1A1A1A" />
          </button>
        </div>
      )}

      {/* Framer Motion Drawer */}
      <AnimatePresence>
        {drawerState !== 'hidden' && (
          <motion.div
            drag="y"
            dragConstraints={{ top: 0, bottom: window.innerHeight * 0.5 }}
            dragElastic={0.2}
            onDragEnd={(e, { offset, velocity }) => {
              if (offset.y > 100 || velocity.y > 500) {
                // Swipe down to close
                setDrawerState('hidden');
                setCapturedImage(null);
                startCamera(); // Restart camera
              } else if (offset.y < -50 || velocity.y < -500) {
                // Swipe up to expand
                setDrawerState('full');
                drawerControls.start({ y: "5%" });
              } else {
                // Snap back to peek
                setDrawerState('peek');
                drawerControls.start({ y: "50%" });
              }
            }}
            initial={{ y: "100%" }}
            animate={drawerControls}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="absolute bottom-0 left-0 right-0 h-[90vh] bg-[#E8E6E1] border-t-[6px] border-x-[6px] border-[#1A1A1A] rounded-t-3xl shadow-[0px_-8px_0px_rgba(0,0,0,0.1)] z-50 flex flex-col"
          >
            {/* Drawer Handle */}
            <div className="w-full flex justify-center py-4 pb-2 cursor-grab active:cursor-grabbing">
              <div className="w-16 h-2 bg-[#1A1A1A] rounded-full opacity-50" />
            </div>
            
            {/* Content */}
            <div className="p-6 overflow-y-auto flex-grow">
              <h3 className="text-xl font-black mb-4 uppercase tracking-wide border-b-4 border-[#1A1A1A] pb-2 inline-block">
                Translation
              </h3>
              <div className="prose prose-lg max-w-none text-[#1A1A1A] font-medium leading-relaxed whitespace-pre-wrap">
                {displayedText}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}